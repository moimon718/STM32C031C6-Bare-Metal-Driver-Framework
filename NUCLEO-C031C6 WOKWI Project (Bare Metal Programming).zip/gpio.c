#include "gpio.h"


/* =========================================================
 * GPIO INITIALIZATION
 * ========================================================= */

void GPIO_Init(GPIO_Handle_t *pGPIOHandle)
{
    uint8_t pin;

    pin = pGPIOHandle->GPIO_Config.GPIO_PinNumber;


    /* -----------------------------------------------------
     * Enable GPIO peripheral clock
     * ----------------------------------------------------- */

    GPIO_PeriClockControl(
        pGPIOHandle->pGPIOx,
        ENABLE
    );


    /* -----------------------------------------------------
     * Configure GPIO MODE
     *
     * Each pin uses 2 bits in MODER.
     *
     * PA5:
     * 2 × 5 = 10
     *
     * Therefore PA5 uses MODER[11:10].
     * ----------------------------------------------------- */

    pGPIOHandle->pGPIOx->MODER &=
        ~(3U << (2U * pin));

    pGPIOHandle->pGPIOx->MODER |=
        ((uint32_t)pGPIOHandle->GPIO_Config.GPIO_PinMode
        << (2U * pin));


    /* -----------------------------------------------------
     * Configure OUTPUT TYPE
     *
     * 0 = Push-Pull
     * 1 = Open-Drain
     * ----------------------------------------------------- */

    pGPIOHandle->pGPIOx->OTYPER &=
        ~(1U << pin);

    pGPIOHandle->pGPIOx->OTYPER |=
        ((uint32_t)pGPIOHandle->GPIO_Config.GPIO_PinOPType
        << pin);


    /* -----------------------------------------------------
     * Configure PULL-UP / PULL-DOWN
     *
     * Each pin uses 2 PUPDR bits.
     * ----------------------------------------------------- */

    pGPIOHandle->pGPIOx->PUPDR &=
        ~(3U << (2U * pin));

    pGPIOHandle->pGPIOx->PUPDR |=
        ((uint32_t)pGPIOHandle->GPIO_Config.GPIO_PinPuPdControl
        << (2U * pin));
}


/* =========================================================
 * GPIO WRITE
 * ========================================================= */

void GPIO_WritePin(GPIO_TypeDef *pGPIOx,
                   uint8_t PinNumber,
                   uint8_t Value)
{
    if (Value)
    {
        /* Set GPIO pin HIGH */

        pGPIOx->BSRR =
            (1U << PinNumber);
    }
    else
    {
        /* Set GPIO pin LOW */

        pGPIOx->BSRR =
            (1U << (PinNumber + 16U));
    }
}


/* =========================================================
 * GPIO TOGGLE
 * ========================================================= */

void GPIO_TogglePin(GPIO_TypeDef *pGPIOx,
                    uint8_t PinNumber)
{
    pGPIOx->ODR ^=
        (1U << PinNumber);
}