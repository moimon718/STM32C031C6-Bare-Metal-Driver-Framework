#include "rcc.h"


/* =========================================================
 * GPIO PERIPHERAL CLOCK CONTROL
 * ========================================================= */

void GPIO_PeriClockControl(GPIO_TypeDef *pGPIOx,
                           uint8_t EnorDi)
{
    if (EnorDi == ENABLE)
    {
        /* GPIOA clock enable */

        if (pGPIOx == GPIOA)
        {
            RCC->IOPENR |= (1U << 0);
        }
    }

    else
    {
        /* GPIOA clock disable */

        if (pGPIOx == GPIOA)
        {
            RCC->IOPENR &= ~(1U << 0);
        }
    }
}