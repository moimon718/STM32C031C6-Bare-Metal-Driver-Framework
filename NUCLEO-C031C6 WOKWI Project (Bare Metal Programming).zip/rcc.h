#ifndef RCC_H
#define RCC_H

#include <Arduino.h>


/* =========================================================
 * ENABLE / DISABLE
 * ========================================================= */

#define ENABLE     1
#define DISABLE    0


/* =========================================================
 * GPIO PERIPHERAL CLOCK CONTROL
 * ========================================================= */

void GPIO_PeriClockControl(GPIO_TypeDef *pGPIOx,
                           uint8_t EnorDi);

#endif